document.addEventListener('DOMContentLoaded', () => {
    console.log('趣派数码网站已加载');
});